RR 3D Kitchen Planner — V2 prototype

This version is designed around the requested screenshot-style workflow:
- Room dimensions: length, width, height
- Add Unit categories: base, drawer, corner, wall, glass, tall, pantry, shelf
- Appliances: built-in sink, hob, chimney, refrigerator, microwave/oven, dishwasher, dustbin
- Ceiling light, plain panel and free worktop
- Cabinet/object width, height, depth, rotation and X/Z position editing
- Handle styles: Normal, G-Profile, L-Shape, Profile, Handle-less
- Horizontal/Vertical handle orientation
- No quotation system
- Automatic collision is OFF
- Designer PDF library: select PDFs from any folder and download them from the in-app list
- Save/load project JSON
- Save design image
- Optional GLB/GLTF model import

This is a browser prototype. 3D assets, PDF persistence across devices, cloud accounts,
login, team sharing, backend storage and production-grade mobile touch controls can be
added in the next development phase.
